package com.task.three.model.entity;

public enum RoleType {
    ADMIN,
    USER;

}
